Sentence Verification Task (SVT) PsychoPy package

Files:
1. SVT_sentence_verification.psyexp
   - Builder-style PsychoPy experiment file.
   - Opens an instruction screen, then runs 88 SVT trials.
   - Key mapping: F = O / 맞음, J = X / 틀림.
   - Reads conditions from SVT_conditions_88items.xlsx.

2. SVT_conditions_88items.xlsx
   - 88 trial condition rows extracted from [부록2].
   - Important columns:
     stimulus = statement shown on screen
     corrAns = correct response key ('f' or 'j')
     correct_label = O/X answer label

Usage:
- Put the .psyexp and .xlsx files in the same folder.
- Open SVT_sentence_verification.psyexp in PsychoPy Builder.
- If PsychoPy asks for the conditions file, select SVT_conditions_88items.xlsx.
- Run the experiment.

Notes:
- Trial order is randomized by the TrialHandler.
- Data are saved as CSV/Excel/log files in a data folder.
