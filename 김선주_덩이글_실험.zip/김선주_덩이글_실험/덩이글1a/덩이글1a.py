#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2026.2.4),
    on Thu Oct  8 15:11:12 2026
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout, hardware
from psychopy.tools import environmenttools
from psychopy.constants import (
    NOT_STARTED, STARTED, PLAYING, PAUSED, STOPPED, STOPPING, FINISHED, PRESSED, 
    RELEASED, FOREVER, priority
)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard

# Run 'Before Experiment' code from trial_code
import json

# Run 'Before Experiment' code from trial_code
import json

# --- Setup global variables (available in all functions) ---
# create a device manager to handle hardware (keyboards, mice, mirophones, speakers, etc.)
deviceManager = hardware.DeviceManager()
# ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
# store info about the experiment session
psychopyVersion = '2026.2.4'
expName = '덩이글1a'  # from the Builder filename that created this script
expVersion = ''
# a list of functions to run when the experiment ends (starts off blank)
runAtExit = []
# information about this experiment
expInfo = {
    'participant': '',
    'age': '',
    'sex': '',
    'date|hid': data.getDateStr(),
    'expName|hid': expName,
    'expVersion|hid': expVersion,
    'psychopyVersion|hid': psychopyVersion,
}

# --- Define some variables which will change depending on pilot mode ---
'''
To run in pilot mode, either use the run/pilot toggle in Builder, Coder and Runner, 
or run the experiment with `--pilot` as an argument. To change what pilot 
#mode does, check out the 'Pilot mode' tab in preferences.
'''
# work out from system args whether we are running in pilot mode
PILOTING = core.setPilotModeFromArgs()
# start off with values from experiment settings
_fullScr = True
_winSize = [1920,1080]
# if in pilot mode, apply overrides according to preferences
if PILOTING:
    # force windowed mode
    if prefs.piloting['forceWindowed']:
        _fullScr = False
        # set window size
        _winSize = prefs.piloting['forcedWindowSize']
    # replace default participant ID
    if prefs.piloting['replaceParticipantID']:
        expInfo['participant'] = 'pilot'

def showExpInfoDlg(expInfo):
    """
    Show participant info dialog.
    Parameters
    ==========
    expInfo : dict
        Information about this experiment.
    
    Returns
    ==========
    dict
        Information about this experiment.
    """
    # show participant info dialog
    dlg = gui.DlgFromDict(
        dictionary=expInfo, sortKeys=False, title=expName, alwaysOnTop=True
    )
    if dlg.OK == False:
        core.quit()  # user pressed cancel
    # return expInfo
    return expInfo


def setupData(expInfo, dataDir=None):
    """
    Make an ExperimentHandler to handle trials and saving.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    dataDir : Path, str or None
        Folder to save the data to, leave as None to create a folder in the current directory.    
    Returns
    ==========
    psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    # remove dialog-specific syntax from expInfo
    for key, val in expInfo.copy().items():
        newKey, _ = data.utils.parsePipeSyntax(key)
        expInfo[newKey] = expInfo.pop(key)
    
    # data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
    if dataDir is None:
        dataDir = _thisDir
    filename = u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])
    # make sure filename is relative to dataDir
    if os.path.isabs(filename):
        dataDir = os.path.commonprefix([dataDir, filename])
        filename = os.path.relpath(filename, dataDir)
    
    # an ExperimentHandler isn't essential but helps with data saving
    thisExp = data.ExperimentHandler(
        name=expName, version=expVersion,
        extraInfo=expInfo, runtimeInfo=None,
        originPath='/Users/namgichun/Library/CloudStorage/SynologyDrive-Data/Cognitive_connectum/김선주_덩이글_실험/덩이글1a/덩이글1a.py',
        savePickle=True, saveWideText=True,
        dataFileName=dataDir + os.sep + filename, sortColumns='time'
    )
    # store pilot mode in data file
    thisExp.addData('piloting', PILOTING, priority=priority.LOW)
    thisExp.setPriority('thisRow.t', priority.CRITICAL)
    thisExp.setPriority('expName', priority.LOW)
    # return experiment handler
    return thisExp


def setupLogging(filename):
    """
    Setup a log file and tell it what level to log at.
    
    Parameters
    ==========
    filename : str or pathlib.Path
        Filename to save log file and data files as, doesn't need an extension.
    
    Returns
    ==========
    psychopy.logging.LogFile
        Text stream to receive inputs from the logging system.
    """
    # set how much information should be printed to the console / app
    if PILOTING:
        logging.console.setLevel(
            prefs.piloting['pilotConsoleLoggingLevel']
        )
    else:
        logging.console.setLevel('warning')
    # save a log file for detail verbose info
    logFile = logging.LogFile(filename+'.log')
    if PILOTING:
        logFile.setLevel(
            prefs.piloting['pilotLoggingLevel']
        )
    else:
        logFile.setLevel(
            logging.getLevel('info')
        )
    
    return logFile


def setupWindow(expInfo=None, win=None):
    """
    Setup the Window
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    win : psychopy.visual.Window
        Window to setup - leave as None to create a new window.
    
    Returns
    ==========
    psychopy.visual.Window
        Window in which to run this experiment.
    """
    if PILOTING:
        logging.debug('Fullscreen settings ignored as running in pilot mode.')
    
    if win is None:
        # if not given a window to setup, make one
        win = visual.Window(
            size=_winSize, fullscr=_fullScr, screen=0,
            winType='pyglet', allowGUI=False, allowStencil=False,
            monitor='testMonitor', color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
            backgroundImage='', backgroundFit='none',
            blendMode='avg', useFBO=True,
            units='norm',
            checkTiming=False  # we're going to do this ourselves in a moment
        )
    else:
        # if we have a window, just set the attributes which are safe to set
        win.color = [-1.0000, -1.0000, -1.0000]
        win.colorSpace = 'rgb'
        win.backgroundImage = ''
        win.backgroundFit = 'none'
        win.units = 'norm'
    if expInfo is not None:
        # get/measure frame rate if not already in expInfo
        if win._monitorFrameRate is None:
            win._monitorFrameRate = win.getActualFrameRate(infoMsg='Attempting to measure frame rate of screen, please wait...')
        expInfo['frameRate'] = win._monitorFrameRate
    win.hideMessage()
    if PILOTING:
        # show a visual indicator if we're in piloting mode
        if prefs.piloting['showPilotingIndicator']:
            win.showPilotingIndicator()
        # always show the mouse in piloting mode
        if prefs.piloting['forceMouseVisible']:
            win.mouseVisible = True
    
    return win


def setupDevices(expInfo, thisExp, win):
    """
    Setup whatever devices are available (mouse, keyboard, speaker, eyetracker, etc.) and add them to 
    the device manager (deviceManager)
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window in which to run this experiment.
    Returns
    ==========
    bool
        True if completed successfully.
    """
    # --- Setup input devices ---
    ioConfig = {}
    ioSession = ioServer = eyetracker = None
    
    # store ioServer object in the device manager
    deviceManager.ioServer = ioServer
    
    # create a default keyboard (e.g. to check for escape)
    if deviceManager.getDevice('defaultKeyboard') is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='ptb'
        )
    # return True if completed successfully
    return True

def pauseExperiment(thisExp, win=None, timers=[], currentRoutine=None):
    """
    Pause this experiment, preventing the flow from advancing to the next routine until resumed.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    timers : list, tuple
        List of timers to reset once pausing is finished.
    currentRoutine : psychopy.data.Routine
        Current Routine we are in at time of pausing, if any. This object tells PsychoPy what Components to pause/play/dispatch.
    """
    # if we are not paused, do nothing
    if thisExp.status != PAUSED:
        return
    
    # start a timer to figure out how long we're paused for
    pauseTimer = core.Clock()
    # pause any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.pause()
    # make sure we have a keyboard
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        defaultKeyboard = deviceManager.addKeyboard(
            deviceClass='keyboard',
            deviceName='defaultKeyboard',
            backend='PsychToolbox',
        )
    # run a while loop while we wait to unpause
    while thisExp.status == PAUSED:
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=['escape']):
            endExperiment(thisExp, win=win)
        # dispatch messages on response components
        if currentRoutine is not None:
            for comp in currentRoutine.getDispatchComponents():
                comp.device.dispatchMessages()
        # sleep 1ms so other threads can execute
        clock.time.sleep(0.001)
    # if stop was requested while paused, quit
    if thisExp.status == FINISHED:
        endExperiment(thisExp, win=win)
    # resume any playback components
    if currentRoutine is not None:
        for comp in currentRoutine.getPlaybackComponents():
            comp.play()
    # reset any timers
    for timer in timers:
        timer.addTime(-pauseTimer.getTime())


def run(expInfo, thisExp, win, globalClock=None, thisSession=None):
    """
    Run the experiment flow.
    
    Parameters
    ==========
    expInfo : dict
        Information about this experiment, created by the `setupExpInfo` function.
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    psychopy.visual.Window
        Window in which to run this experiment.
    globalClock : psychopy.core.clock.Clock or None
        Clock to get global time from - supply None to make a new one.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    # mark experiment as started
    thisExp.status = STARTED
    # update experiment info
    expInfo['date'] = data.getDateStr()
    expInfo['expName'] = expName
    expInfo['expVersion'] = expVersion
    expInfo['psychopyVersion'] = psychopyVersion
    # make sure window is set to foreground to prevent losing focus
    win.winHandle.activate()
    # make sure variables created by exec are available globally
    exec = environmenttools.setExecEnvironment(globals())
    # get device handles from dict of input devices
    ioServer = deviceManager.ioServer
    # get/create a default keyboard (e.g. to check for escape)
    defaultKeyboard = deviceManager.getDevice('defaultKeyboard')
    if defaultKeyboard is None:
        deviceManager.addDevice(
            deviceClass='keyboard', deviceName='defaultKeyboard', backend='PsychToolbox'
        )
    eyetracker = deviceManager.getDevice('eyetracker')
    # make sure we're running in the directory for this experiment
    os.chdir(_thisDir)
    # get filename from ExperimentHandler for convenience
    filename = thisExp.dataFileName
    frameTolerance = 0.001  # how close to onset before 'same' frame
    endExpNow = False  # flag for 'escape' or other condition => quit the exp
    # get frame duration from frame rate in expInfo
    if 'frameRate' in expInfo and expInfo['frameRate'] is not None:
        frameDur = 1.0 / round(expInfo['frameRate'])
    else:
        frameDur = 1.0 / 60.0  # could not measure, so guess
    
    # Start Code - component code to be run after the window creation
    
    # --- Initialize components for Routine "Intro" ---
    Intro_txt = visual.TextStim(win=win, name='Intro_txt',
        text='실험에 참여해 주셔서 감사합니다.\n\n아무 키나 눌러서 넘겨 주세요.',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    Intro_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "Instruction" ---
    Instruction_txt = visual.TextStim(win=win, name='Instruction_txt',
        text="문장 덩어리들이 제시됩니다.\n한 문장씩 제시되며, 각 문장에서 어절들이 앞에서부터 순서대로 제시됩니다.\n\n글을 읽는 도중 **로 둘러싸인 검사단어가 나타납니다.\n그 단어가 앞서 이 글에 나왔던 단어이면 'f'키를,\n나온 적이 없는 단어이면 'j'키를 눌러 주세요.\n\n모든 문장이 제시된 후 글 내용에 대한 질문이 나옵니다.\n질문에도 'f'와 'j'로 답해 주세요.\n\n스페이스 바를 눌러 연습시행을 시작합니다.",
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.045, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    Instruction_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "PracticeIntro" ---
    PracticeIntro_txt = visual.TextStim(win=win, name='PracticeIntro_txt',
        text='지금부터 연습시행을 시작합니다.\n\n스페이스바를 눌러 시작해 주세요.',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    PracticeIntro_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "Ready" ---
    Ready_txt = visual.TextStim(win=win, name='Ready_txt',
        text='준비되었으면 스페이스바를 눌러 주세요',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    Ready_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "Trial" ---
    # Run 'Begin Experiment' code from trial_code
    # ============================================================
    #  덩이글 과제 — 김선주(1994) 대용어 참조 실험
    #  어절 단위 누적 제시는 Builder 기본 컴포넌트로 만들 수 없어
    #  이 코드 컴포넌트에 구현했습니다.
    #
    #  [중요] 어절 위치를 직접 계산하지 않습니다.
    #  화면에 그릴 때마다 '지금까지의 어절을 공백으로 이은 한 줄'을
    #  왼쪽 끝을 고정한 TextStim 하나로 그립니다. 다음 단계의 문자열은
    #  앞 단계 문자열의 앞부분이 그대로이므로, 이미 나온 어절은
    #  PsychoPy 가 알아서 같은 자리에 유지합니다.
    #  (픽셀 폭을 재서 좌표를 잡으면 맥 Retina 처럼 화면 픽셀과
    #   좌표계 배율이 다른 환경에서 어절이 겹칩니다.)
    # ============================================================
    
    # ── 반응키 ───────────────────────────────────────────────
    KEY_LEFT  = 'f'          # 예 / 적절 / 첫번째 보기
    KEY_RIGHT = 'j'          # 아니오 / 부적절 / 두번째 보기
    RESP_KEYS = [KEY_LEFT, KEY_RIGHT, 'escape']
    
    # ── 과제 유형 ─────────────────────────────────────────────
    TASK_MODE = 'recognition'      # 'recognition' = 재인 / 'context' = 맥락검증
    
    # ── 화면 (norm 단위) ──────────────────────────────────────
    FONT_NAME   = 'AppleGothic'      # 맥 기본 한글 폰트
    TEXT_HEIGHT = 0.07               # 어절 글자 크기
    TEXT_Y      =  0.10              # 글줄의 세로 위치
    LINE_WIDTH  =  1.90              # 한 줄이 쓸 수 있는 가로 폭
    LEFT_MIN    = -0.92              # 문장 시작점이 여기보다 더 왼쪽으로는 안 감
    
    # 문장이 완성됐을 때 화면 가운데 오도록, 문장의 가로 폭을 글자 종류로 어림한다.
    # 한글 음절은 전각(정사각), 영문·숫자·문장부호는 대략 절반, 공백은 그보다 좁다.
    # 이 값은 '문장을 어디서 시작할지'만 정하므로, 어림이 조금 빗나가도
    # 문장이 좌우로 살짝 치우칠 뿐 어절 간격에는 전혀 영향이 없다.
    # (어절 배치는 PsychoPy 가 하고, 이 코드는 시작점만 잡는다.)
    HANGUL_RATIO = 1.00
    LATIN_RATIO  = 0.50
    SPACE_RATIO  = 0.30
    
    # ── 타이밍 (논문 p.33) ────────────────────────────────────
    WORD_DURATION     = 0.5   # 어절 하나가 추가되는 간격
    SENTENCE_HOLD     = 0.5   # 문장 완성 후 추가로 유지하는 시간
    SENTENCE_ISI      = 0.5   # 문장이 사라진 뒤 다음 문장까지의 공백
    FEEDBACK_DURATION = 1.0   # 연습시행 피드백 제시 시간
    
    # ── 검사단어 제시 방식 ────────────────────────────────────
    # True  : 논문대로. 검사단어가 나타나면 앞 어절은 화면에서 사라지고
    #         검사단어만 제 자리에 남는다.
    #         (앞 어절을 배경색으로 덧그려 지웁니다. 가장자리 잔상을
    #          없애려고 ERASE_PASSES 번 반복해 그립니다.)
    # False : 앞 어절과 함께 보여 준 뒤 빈 화면에서 반응을 받는다.
    #         지우기가 화면에서 어색해 보이면 이쪽으로 바꾸세요.
    PROBE_ALONE  = True
    ERASE_PASSES = 4
    
    # ── 반응 수집용 키보드 (PsychToolbox 정밀 타이밍) ──────────
    resp_kb = keyboard.Keyboard()
    
    
    def est_width(text):
        """문장의 가로 폭을 norm 단위로 어림한다.
    
        norm 좌표계는 가로와 세로의 배율이 달라서, 정사각형 글자의 가로 폭은
        글자 높이에 '화면 세로/가로 비율'을 곱한 값이다.
        win.size 의 절대값이 아니라 비율만 쓰기 때문에, 맥 Retina 처럼
        화면 픽셀과 좌표계 배율이 다른 환경에서도 안전하다.
        """
        em = TEXT_HEIGHT * (float(win.size[1]) / float(win.size[0]))
        total = 0.0
        for ch in text:
            if ch == ' ':
                total += em * SPACE_RATIO
            elif '가' <= ch <= '힣':      # 한글 음절
                total += em * HANGUL_RATIO
            else:                                 # 영문·숫자·문장부호
                total += em * LATIN_RATIO
        return total
    
    
    def sentence_start_x(words):
        """문장이 다 제시됐을 때 가운데 오도록 시작 x 좌표를 정한다.
    
        문장마다 한 번만 구해서 그 문장 내내 그대로 쓰므로,
        어절이 하나씩 붙어도 이미 나온 어절은 움직이지 않는다.
        """
        x = -est_width(' '.join(words)) / 2.0
        return x if x > LEFT_MIN else LEFT_MIN
    
    
    def make_line(text, start_x, color='white'):
        """왼쪽 끝을 start_x 에 고정한 한 줄. 어절 배치는 PsychoPy 에 맡긴다."""
        kw = dict(text=text, font=FONT_NAME, color=color, height=TEXT_HEIGHT,
                  pos=(start_x, TEXT_Y), wrapWidth=LINE_WIDTH, units='norm')
        try:
            return visual.TextStim(win, alignText='left', anchorHoriz='left', **kw)
        except TypeError:                      # 구버전 PsychoPy
            return visual.TextStim(win, alignHoriz='left', **kw)
    
    
    def make_center(text, y=0.0, height=0.06, color='white'):
        """가운데 정렬 안내문 / 질문용."""
        kw = dict(text=text, font=FONT_NAME, color=color, height=height,
                  pos=(0, y), wrapWidth=1.7, units='norm')
        try:
            return visual.TextStim(win, alignText='center', anchorHoriz='center', **kw)
        except TypeError:
            return visual.TextStim(win, alignHoriz='center', **kw)
    
    
    def split_probe(sentence):
        """문장에서 **검사단어** 를 떼어낸다.
    
        반환: (검사단어 뺀 어절 리스트, 검사단어, 검사단어가 들어갈 순번)
        순번은 '검사단어 앞에 놓인 어절의 개수' 이므로,
        문장 맨 끝에 있었다면 어절 개수와 같다.
        """
        words, probe, probe_at = [], None, None
        for token in sentence:
            if probe is None and '**' in token:
                probe, probe_at = token, len(words)
            else:
                words.append(token)
        return words, probe, probe_at
    
    
    def draw_probe_frame(prefix, probe, start_x):
        """검사단어를 제 자리에 그린다.
    
        앞 어절들과 검사단어를 한 줄로 그린 다음, 앞 어절만 배경색으로
        덧그려 지운다. 같은 폰트·크기·정렬이라 글자 위치가 정확히 겹치므로
        검사단어의 가로 위치를 따로 계산할 필요가 없다.
        """
        line = (prefix + ' ' + probe) if prefix else probe
        make_line(line, start_x).draw()
        if PROBE_ALONE and prefix:
            eraser = make_line(prefix, start_x, color=win.color)
            for _ in range(ERASE_PASSES):
                eraser.draw()
    
    
    def probe_correct_key(ptype):
        """검사단어 과제의 정답 키."""
        if TASK_MODE == 'context':
            # 맥락검증: 대용어가 가리키는 대상으로 적절한가?
            # 참조어만 적절, 비참조어와 무관단어(X)는 부적절.
            return KEY_LEFT if ptype == '참조어' else KEY_RIGHT
        # 재인: 앞서 글에 나왔던 단어인가? 무관단어(X)만 '아니오'.
        return KEY_RIGHT if ptype == 'X' else KEY_LEFT
    
    
    def collect_response():
        """반응 하나를 받아 (키, 반응시간) 반환. escape 면 실험 종료."""
        resp_kb.clearEvents()
        resp_kb.clock.reset()
        pressed = resp_kb.waitKeys(keyList=RESP_KEYS, waitRelease=False)
        key = pressed[0]
        if key.name == 'escape':
            thisExp.status = FINISHED
            endExperiment(thisExp, win=win)
            core.quit()
        return key.name, key.rt
    
    
    def show_feedback(correct):
        make_center('정답입니다!' if correct else '틀렸습니다!', color='yellow').draw()
        win.flip()
        core.wait(FEEDBACK_DURATION)
    
    
    # --- Initialize components for Routine "MainIntro" ---
    MainIntro_txt = visual.TextStim(win=win, name='MainIntro_txt',
        text='연습시행을 모두 마쳤습니다.\n지금부터 본 실험을 시작하겠습니다.\n본 실험에선 정답 여부를 알려드리지 않습니다.\n\n스페이스바를 눌러 시작해 주세요.',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    MainIntro_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "Ready" ---
    Ready_txt = visual.TextStim(win=win, name='Ready_txt',
        text='준비되었으면 스페이스바를 눌러 주세요',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    Ready_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # --- Initialize components for Routine "Trial" ---
    # Run 'Begin Experiment' code from trial_code
    # ============================================================
    #  덩이글 과제 — 김선주(1994) 대용어 참조 실험
    #  어절 단위 누적 제시는 Builder 기본 컴포넌트로 만들 수 없어
    #  이 코드 컴포넌트에 구현했습니다.
    #
    #  [중요] 어절 위치를 직접 계산하지 않습니다.
    #  화면에 그릴 때마다 '지금까지의 어절을 공백으로 이은 한 줄'을
    #  왼쪽 끝을 고정한 TextStim 하나로 그립니다. 다음 단계의 문자열은
    #  앞 단계 문자열의 앞부분이 그대로이므로, 이미 나온 어절은
    #  PsychoPy 가 알아서 같은 자리에 유지합니다.
    #  (픽셀 폭을 재서 좌표를 잡으면 맥 Retina 처럼 화면 픽셀과
    #   좌표계 배율이 다른 환경에서 어절이 겹칩니다.)
    # ============================================================
    
    # ── 반응키 ───────────────────────────────────────────────
    KEY_LEFT  = 'f'          # 예 / 적절 / 첫번째 보기
    KEY_RIGHT = 'j'          # 아니오 / 부적절 / 두번째 보기
    RESP_KEYS = [KEY_LEFT, KEY_RIGHT, 'escape']
    
    # ── 과제 유형 ─────────────────────────────────────────────
    TASK_MODE = 'recognition'      # 'recognition' = 재인 / 'context' = 맥락검증
    
    # ── 화면 (norm 단위) ──────────────────────────────────────
    FONT_NAME   = 'AppleGothic'      # 맥 기본 한글 폰트
    TEXT_HEIGHT = 0.07               # 어절 글자 크기
    TEXT_Y      =  0.10              # 글줄의 세로 위치
    LINE_WIDTH  =  1.90              # 한 줄이 쓸 수 있는 가로 폭
    LEFT_MIN    = -0.92              # 문장 시작점이 여기보다 더 왼쪽으로는 안 감
    
    # 문장이 완성됐을 때 화면 가운데 오도록, 문장의 가로 폭을 글자 종류로 어림한다.
    # 한글 음절은 전각(정사각), 영문·숫자·문장부호는 대략 절반, 공백은 그보다 좁다.
    # 이 값은 '문장을 어디서 시작할지'만 정하므로, 어림이 조금 빗나가도
    # 문장이 좌우로 살짝 치우칠 뿐 어절 간격에는 전혀 영향이 없다.
    # (어절 배치는 PsychoPy 가 하고, 이 코드는 시작점만 잡는다.)
    HANGUL_RATIO = 1.00
    LATIN_RATIO  = 0.50
    SPACE_RATIO  = 0.30
    
    # ── 타이밍 (논문 p.33) ────────────────────────────────────
    WORD_DURATION     = 0.5   # 어절 하나가 추가되는 간격
    SENTENCE_HOLD     = 0.5   # 문장 완성 후 추가로 유지하는 시간
    SENTENCE_ISI      = 0.5   # 문장이 사라진 뒤 다음 문장까지의 공백
    FEEDBACK_DURATION = 1.0   # 연습시행 피드백 제시 시간
    
    # ── 검사단어 제시 방식 ────────────────────────────────────
    # True  : 논문대로. 검사단어가 나타나면 앞 어절은 화면에서 사라지고
    #         검사단어만 제 자리에 남는다.
    #         (앞 어절을 배경색으로 덧그려 지웁니다. 가장자리 잔상을
    #          없애려고 ERASE_PASSES 번 반복해 그립니다.)
    # False : 앞 어절과 함께 보여 준 뒤 빈 화면에서 반응을 받는다.
    #         지우기가 화면에서 어색해 보이면 이쪽으로 바꾸세요.
    PROBE_ALONE  = True
    ERASE_PASSES = 4
    
    # ── 반응 수집용 키보드 (PsychToolbox 정밀 타이밍) ──────────
    resp_kb = keyboard.Keyboard()
    
    
    def est_width(text):
        """문장의 가로 폭을 norm 단위로 어림한다.
    
        norm 좌표계는 가로와 세로의 배율이 달라서, 정사각형 글자의 가로 폭은
        글자 높이에 '화면 세로/가로 비율'을 곱한 값이다.
        win.size 의 절대값이 아니라 비율만 쓰기 때문에, 맥 Retina 처럼
        화면 픽셀과 좌표계 배율이 다른 환경에서도 안전하다.
        """
        em = TEXT_HEIGHT * (float(win.size[1]) / float(win.size[0]))
        total = 0.0
        for ch in text:
            if ch == ' ':
                total += em * SPACE_RATIO
            elif '가' <= ch <= '힣':      # 한글 음절
                total += em * HANGUL_RATIO
            else:                                 # 영문·숫자·문장부호
                total += em * LATIN_RATIO
        return total
    
    
    def sentence_start_x(words):
        """문장이 다 제시됐을 때 가운데 오도록 시작 x 좌표를 정한다.
    
        문장마다 한 번만 구해서 그 문장 내내 그대로 쓰므로,
        어절이 하나씩 붙어도 이미 나온 어절은 움직이지 않는다.
        """
        x = -est_width(' '.join(words)) / 2.0
        return x if x > LEFT_MIN else LEFT_MIN
    
    
    def make_line(text, start_x, color='white'):
        """왼쪽 끝을 start_x 에 고정한 한 줄. 어절 배치는 PsychoPy 에 맡긴다."""
        kw = dict(text=text, font=FONT_NAME, color=color, height=TEXT_HEIGHT,
                  pos=(start_x, TEXT_Y), wrapWidth=LINE_WIDTH, units='norm')
        try:
            return visual.TextStim(win, alignText='left', anchorHoriz='left', **kw)
        except TypeError:                      # 구버전 PsychoPy
            return visual.TextStim(win, alignHoriz='left', **kw)
    
    
    def make_center(text, y=0.0, height=0.06, color='white'):
        """가운데 정렬 안내문 / 질문용."""
        kw = dict(text=text, font=FONT_NAME, color=color, height=height,
                  pos=(0, y), wrapWidth=1.7, units='norm')
        try:
            return visual.TextStim(win, alignText='center', anchorHoriz='center', **kw)
        except TypeError:
            return visual.TextStim(win, alignHoriz='center', **kw)
    
    
    def split_probe(sentence):
        """문장에서 **검사단어** 를 떼어낸다.
    
        반환: (검사단어 뺀 어절 리스트, 검사단어, 검사단어가 들어갈 순번)
        순번은 '검사단어 앞에 놓인 어절의 개수' 이므로,
        문장 맨 끝에 있었다면 어절 개수와 같다.
        """
        words, probe, probe_at = [], None, None
        for token in sentence:
            if probe is None and '**' in token:
                probe, probe_at = token, len(words)
            else:
                words.append(token)
        return words, probe, probe_at
    
    
    def draw_probe_frame(prefix, probe, start_x):
        """검사단어를 제 자리에 그린다.
    
        앞 어절들과 검사단어를 한 줄로 그린 다음, 앞 어절만 배경색으로
        덧그려 지운다. 같은 폰트·크기·정렬이라 글자 위치가 정확히 겹치므로
        검사단어의 가로 위치를 따로 계산할 필요가 없다.
        """
        line = (prefix + ' ' + probe) if prefix else probe
        make_line(line, start_x).draw()
        if PROBE_ALONE and prefix:
            eraser = make_line(prefix, start_x, color=win.color)
            for _ in range(ERASE_PASSES):
                eraser.draw()
    
    
    def probe_correct_key(ptype):
        """검사단어 과제의 정답 키."""
        if TASK_MODE == 'context':
            # 맥락검증: 대용어가 가리키는 대상으로 적절한가?
            # 참조어만 적절, 비참조어와 무관단어(X)는 부적절.
            return KEY_LEFT if ptype == '참조어' else KEY_RIGHT
        # 재인: 앞서 글에 나왔던 단어인가? 무관단어(X)만 '아니오'.
        return KEY_RIGHT if ptype == 'X' else KEY_LEFT
    
    
    def collect_response():
        """반응 하나를 받아 (키, 반응시간) 반환. escape 면 실험 종료."""
        resp_kb.clearEvents()
        resp_kb.clock.reset()
        pressed = resp_kb.waitKeys(keyList=RESP_KEYS, waitRelease=False)
        key = pressed[0]
        if key.name == 'escape':
            thisExp.status = FINISHED
            endExperiment(thisExp, win=win)
            core.quit()
        return key.name, key.rt
    
    
    def show_feedback(correct):
        make_center('정답입니다!' if correct else '틀렸습니다!', color='yellow').draw()
        win.flip()
        core.wait(FEEDBACK_DURATION)
    
    
    # --- Initialize components for Routine "Outro" ---
    Outro_txt = visual.TextStim(win=win, name='Outro_txt',
        text='실험이 모두 종료되었습니다.\n\n참가해 주셔서 감사합니다.',
        font='AppleGothic',
        pos=(0, 0), draggable=False, height=0.055, wrapWidth=1.7, ori=0.0, 
        color='white', colorSpace='rgb', opacity=None, 
        languageStyle='LTR',
        depth=0.0);
    Outro_key = keyboard.Keyboard(deviceName='defaultKeyboard', backend='PsychToolbox')
    
    # create some handy timers
    
    # global clock to track the time since experiment started
    if globalClock is None:
        # create a clock if not given one
        globalClock = core.Clock()
    if isinstance(globalClock, str):
        # if given a string, make a clock accoridng to it
        if globalClock == 'float':
            # get timestamps as a simple value
            globalClock = core.Clock(format='float')
        elif globalClock == 'iso':
            # get timestamps in ISO format
            globalClock = core.Clock(format='%Y-%m-%d_%H:%M:%S.%f%z')
        else:
            # get timestamps in a custom format
            globalClock = core.Clock(format=globalClock)
    if ioServer is not None:
        ioServer.syncClock(globalClock)
    logging.setDefaultClock(globalClock)
    if eyetracker is not None:
        eyetracker.enableEventReporting()
    # routine timer to track time remaining of each (possibly non-slip) routine
    routineTimer = core.Clock()
    win.flip()  # flip window to reset last flip timer
    # store the exact time the global clock started
    expInfo['expStart'] = data.getDateStr(
        format='%Y-%m-%d %Hh%M.%S.%f %z', fractionalSecondDigits=6
    )
    
    # --- Prepare to start Routine "Intro" ---
    # create an object to store info about Routine Intro
    Intro = data.Routine(
        name='Intro',
        components=[Intro_txt, Intro_key],
    )
    Intro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for Intro_key
    Intro_key.keys = []
    Intro_key.rt = []
    _Intro_key_allKeys = []
    # store start times for Intro
    Intro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Intro.tStart = globalClock.getTime(format='float')
    Intro.status = STARTED
    thisExp.addData('Intro.started', Intro.tStart)
    Intro.maxDuration = None
    # keep track of which components have finished
    IntroComponents = Intro.components
    for thisComponent in Intro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Intro" ---
    thisExp.currentRoutine = Intro
    Intro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Intro_txt* updates
        
        # if Intro_txt is starting this frame...
        if Intro_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Intro_txt.frameNStart = frameN  # exact frame index
            Intro_txt.tStart = t  # local t and not account for scr refresh
            Intro_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Intro_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Intro_txt.started')
            # update status
            Intro_txt.status = STARTED
            Intro_txt.setAutoDraw(True)
        
        # if Intro_txt is active this frame...
        if Intro_txt.status == STARTED:
            # update params
            pass
        
        # *Intro_key* updates
        waitOnFlip = False
        
        # if Intro_key is starting this frame...
        if Intro_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Intro_key.frameNStart = frameN  # exact frame index
            Intro_key.tStart = t  # local t and not account for scr refresh
            Intro_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Intro_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Intro_key.started')
            # update status
            Intro_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Intro_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Intro_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Intro_key.status == STARTED and not waitOnFlip:
            theseKeys = Intro_key.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _Intro_key_allKeys.extend(theseKeys)
            if len(_Intro_key_allKeys):
                Intro_key.keys = _Intro_key_allKeys[-1].name  # just the last key pressed
                Intro_key.rt = _Intro_key_allKeys[-1].rt
                Intro_key.duration = _Intro_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Intro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Intro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Intro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Intro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Intro" ---
    for thisComponent in Intro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Intro
    Intro.tStop = globalClock.getTime(format='float')
    Intro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Intro.stopped', Intro.tStop)
    thisExp.nextEntry()
    # the Routine "Intro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "Instruction" ---
    # create an object to store info about Routine Instruction
    Instruction = data.Routine(
        name='Instruction',
        components=[Instruction_txt, Instruction_key],
    )
    Instruction.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for Instruction_key
    Instruction_key.keys = []
    Instruction_key.rt = []
    _Instruction_key_allKeys = []
    # store start times for Instruction
    Instruction.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Instruction.tStart = globalClock.getTime(format='float')
    Instruction.status = STARTED
    thisExp.addData('Instruction.started', Instruction.tStart)
    Instruction.maxDuration = None
    # keep track of which components have finished
    InstructionComponents = Instruction.components
    for thisComponent in Instruction.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Instruction" ---
    thisExp.currentRoutine = Instruction
    Instruction.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Instruction_txt* updates
        
        # if Instruction_txt is starting this frame...
        if Instruction_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Instruction_txt.frameNStart = frameN  # exact frame index
            Instruction_txt.tStart = t  # local t and not account for scr refresh
            Instruction_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Instruction_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Instruction_txt.started')
            # update status
            Instruction_txt.status = STARTED
            Instruction_txt.setAutoDraw(True)
        
        # if Instruction_txt is active this frame...
        if Instruction_txt.status == STARTED:
            # update params
            pass
        
        # *Instruction_key* updates
        waitOnFlip = False
        
        # if Instruction_key is starting this frame...
        if Instruction_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Instruction_key.frameNStart = frameN  # exact frame index
            Instruction_key.tStart = t  # local t and not account for scr refresh
            Instruction_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Instruction_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Instruction_key.started')
            # update status
            Instruction_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Instruction_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Instruction_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Instruction_key.status == STARTED and not waitOnFlip:
            theseKeys = Instruction_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _Instruction_key_allKeys.extend(theseKeys)
            if len(_Instruction_key_allKeys):
                Instruction_key.keys = _Instruction_key_allKeys[-1].name  # just the last key pressed
                Instruction_key.rt = _Instruction_key_allKeys[-1].rt
                Instruction_key.duration = _Instruction_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Instruction,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Instruction.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Instruction.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Instruction.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Instruction" ---
    for thisComponent in Instruction.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Instruction
    Instruction.tStop = globalClock.getTime(format='float')
    Instruction.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Instruction.stopped', Instruction.tStop)
    thisExp.nextEntry()
    # the Routine "Instruction" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "PracticeIntro" ---
    # create an object to store info about Routine PracticeIntro
    PracticeIntro = data.Routine(
        name='PracticeIntro',
        components=[PracticeIntro_txt, PracticeIntro_key],
    )
    PracticeIntro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for PracticeIntro_key
    PracticeIntro_key.keys = []
    PracticeIntro_key.rt = []
    _PracticeIntro_key_allKeys = []
    # store start times for PracticeIntro
    PracticeIntro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    PracticeIntro.tStart = globalClock.getTime(format='float')
    PracticeIntro.status = STARTED
    thisExp.addData('PracticeIntro.started', PracticeIntro.tStart)
    PracticeIntro.maxDuration = None
    # keep track of which components have finished
    PracticeIntroComponents = PracticeIntro.components
    for thisComponent in PracticeIntro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "PracticeIntro" ---
    thisExp.currentRoutine = PracticeIntro
    PracticeIntro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *PracticeIntro_txt* updates
        
        # if PracticeIntro_txt is starting this frame...
        if PracticeIntro_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            PracticeIntro_txt.frameNStart = frameN  # exact frame index
            PracticeIntro_txt.tStart = t  # local t and not account for scr refresh
            PracticeIntro_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracticeIntro_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'PracticeIntro_txt.started')
            # update status
            PracticeIntro_txt.status = STARTED
            PracticeIntro_txt.setAutoDraw(True)
        
        # if PracticeIntro_txt is active this frame...
        if PracticeIntro_txt.status == STARTED:
            # update params
            pass
        
        # *PracticeIntro_key* updates
        waitOnFlip = False
        
        # if PracticeIntro_key is starting this frame...
        if PracticeIntro_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            PracticeIntro_key.frameNStart = frameN  # exact frame index
            PracticeIntro_key.tStart = t  # local t and not account for scr refresh
            PracticeIntro_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracticeIntro_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'PracticeIntro_key.started')
            # update status
            PracticeIntro_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(PracticeIntro_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(PracticeIntro_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if PracticeIntro_key.status == STARTED and not waitOnFlip:
            theseKeys = PracticeIntro_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _PracticeIntro_key_allKeys.extend(theseKeys)
            if len(_PracticeIntro_key_allKeys):
                PracticeIntro_key.keys = _PracticeIntro_key_allKeys[-1].name  # just the last key pressed
                PracticeIntro_key.rt = _PracticeIntro_key_allKeys[-1].rt
                PracticeIntro_key.duration = _PracticeIntro_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=PracticeIntro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            PracticeIntro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if PracticeIntro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in PracticeIntro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "PracticeIntro" ---
    for thisComponent in PracticeIntro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for PracticeIntro
    PracticeIntro.tStop = globalClock.getTime(format='float')
    PracticeIntro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('PracticeIntro.stopped', PracticeIntro.tStop)
    thisExp.nextEntry()
    # the Routine "PracticeIntro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    practice_loop = data.TrialHandler2(
        name='practice_loop',
        nReps=1.0, 
        method='sequential', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('conditions/practice.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(practice_loop)  # add the loop to the experiment
    thisPractice_loop = practice_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
    if thisPractice_loop != None:
        for paramName in thisPractice_loop:
            globals()[paramName] = thisPractice_loop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisPractice_loop in practice_loop:
        practice_loop.status = STARTED
        if hasattr(thisPractice_loop, 'status'):
            thisPractice_loop.status = STARTED
        currentLoop = practice_loop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
        if thisPractice_loop != None:
            for paramName in thisPractice_loop:
                globals()[paramName] = thisPractice_loop[paramName]
        
        # --- Prepare to start Routine "Ready" ---
        # create an object to store info about Routine Ready
        Ready = data.Routine(
            name='Ready',
            components=[Ready_txt, Ready_key],
        )
        Ready.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for Ready_key
        Ready_key.keys = []
        Ready_key.rt = []
        _Ready_key_allKeys = []
        # store start times for Ready
        Ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Ready.tStart = globalClock.getTime(format='float')
        Ready.status = STARTED
        thisExp.addData('Ready.started', Ready.tStart)
        Ready.maxDuration = None
        # keep track of which components have finished
        ReadyComponents = Ready.components
        for thisComponent in Ready.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Ready" ---
        thisExp.currentRoutine = Ready
        Ready.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPractice_loop, 'status') and thisPractice_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Ready_txt* updates
            
            # if Ready_txt is starting this frame...
            if Ready_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Ready_txt.frameNStart = frameN  # exact frame index
                Ready_txt.tStart = t  # local t and not account for scr refresh
                Ready_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Ready_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Ready_txt.started')
                # update status
                Ready_txt.status = STARTED
                Ready_txt.setAutoDraw(True)
            
            # if Ready_txt is active this frame...
            if Ready_txt.status == STARTED:
                # update params
                pass
            
            # *Ready_key* updates
            waitOnFlip = False
            
            # if Ready_key is starting this frame...
            if Ready_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Ready_key.frameNStart = frameN  # exact frame index
                Ready_key.tStart = t  # local t and not account for scr refresh
                Ready_key.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Ready_key, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Ready_key.started')
                # update status
                Ready_key.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(Ready_key.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(Ready_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if Ready_key.status == STARTED and not waitOnFlip:
                theseKeys = Ready_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _Ready_key_allKeys.extend(theseKeys)
                if len(_Ready_key_allKeys):
                    Ready_key.keys = _Ready_key_allKeys[-1].name  # just the last key pressed
                    Ready_key.rt = _Ready_key_allKeys[-1].rt
                    Ready_key.duration = _Ready_key_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Ready,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Ready.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Ready.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Ready.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Ready" ---
        for thisComponent in Ready.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Ready
        Ready.tStop = globalClock.getTime(format='float')
        Ready.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Ready.stopped', Ready.tStop)
        # the Routine "Ready" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Trial" ---
        # create an object to store info about Routine Trial
        Trial = data.Routine(
            name='Trial',
            components=[],
        )
        Trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from trial_code
        # ── 한 시행 전체 ──────────────────────────────────────────
        # PsychoPy 의 importConditions 는 '[' 로 시작하는 셀을 읽을 때 자동으로 eval 해서
        # 이미 파이썬 리스트로 넘겨준다. 그래서 문자열일 때만 json 으로 푼다.
        if isinstance(sentences_json, str):
            sentences = json.loads(sentences_json)
        else:
            sentences = [list(s) for s in sentences_json]
        is_prac = bool(int(practice))
        
        probe_response = None
        probe_rt       = None
        probe_correct  = None
        probe_done     = False
        
        for sentence in sentences:
            words, probe, probe_at = split_probe(sentence)
            start_x = sentence_start_x(words)      # 이 문장 내내 고정
        
            for step in range(len(words) + 1):
                # 검사단어 차례
                if probe is not None and not probe_done and step == probe_at:
                    draw_probe_frame(' '.join(words[:step]), probe, start_x)
                    win.flip()
                    probe_response, probe_rt = collect_response()
                    probe_correct = (probe_response == probe_correct_key(probe_type))
                    probe_done = True
                    if not PROBE_ALONE:
                        win.flip()          # 앞 어절과 함께 보여준 경우 화면을 비운다
                    if is_prac:
                        show_feedback(probe_correct)
        
                if step == len(words):
                    break
        
                make_line(' '.join(words[:step + 1]), start_x).draw()
                win.flip()
                core.wait(WORD_DURATION)
        
            # 논문 절차: 마지막 어절 제시 후 문장을 추가로 유지했다가,
            # 화면을 비우고 일정 시간이 지난 뒤 다음 문장을 제시한다.
            make_line(' '.join(words), start_x).draw()
            win.flip()
            core.wait(SENTENCE_HOLD)
            win.flip()
            core.wait(SENTENCE_ISI)
        
        # ── 이해검사 질문 ─────────────────────────────────────────
        make_center(question, y=0.10, height=0.06).draw()
        make_center('%s: %s    %s: %s' % (KEY_LEFT, opt1, KEY_RIGHT, opt2),
                    y=-0.10, height=0.06).draw()
        win.flip()
        quest_response, quest_rt = collect_response()
        quest_correct = (quest_response == ans_key)
        if is_prac:
            show_feedback(quest_correct)
        
        # ── 기록 ─────────────────────────────────────────────────
        thisExp.addData('probe_task',  'context' if TASK_MODE == 'context' else 'recognition')
        thisExp.addData('probe_resp',  probe_response)
        thisExp.addData('probe_corr',  int(bool(probe_correct)))
        thisExp.addData('probe_rt',    probe_rt)
        thisExp.addData('quest_resp',  quest_response)
        thisExp.addData('quest_corr',  int(quest_correct))
        thisExp.addData('quest_rt',    quest_rt)
        
        # 제시와 반응 수집이 모두 이 코드 안에서 끝나므로 프레임 루프는 돌지 않는다.
        continueRoutine = False
        
        # store start times for Trial
        Trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Trial.tStart = globalClock.getTime(format='float')
        Trial.status = STARTED
        thisExp.addData('Trial.started', Trial.tStart)
        Trial.maxDuration = None
        # keep track of which components have finished
        TrialComponents = Trial.components
        for thisComponent in Trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Trial" ---
        thisExp.currentRoutine = Trial
        Trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisPractice_loop, 'status') and thisPractice_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Trial" ---
        for thisComponent in Trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Trial
        Trial.tStop = globalClock.getTime(format='float')
        Trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Trial.stopped', Trial.tStop)
        # the Routine "Trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisPractice_loop as finished
        if hasattr(thisPractice_loop, 'status'):
            thisPractice_loop.status = FINISHED
        # if awaiting a pause, pause now
        if practice_loop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            practice_loop.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'practice_loop'
    practice_loop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if practice_loop.trialList in ([], [None], None):
        params = []
    else:
        params = practice_loop.trialList[0].keys()
    # save data for this loop
    practice_loop.saveAsExcel(filename + '.xlsx', sheetName='practice_loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "MainIntro" ---
    # create an object to store info about Routine MainIntro
    MainIntro = data.Routine(
        name='MainIntro',
        components=[MainIntro_txt, MainIntro_key],
    )
    MainIntro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for MainIntro_key
    MainIntro_key.keys = []
    MainIntro_key.rt = []
    _MainIntro_key_allKeys = []
    # store start times for MainIntro
    MainIntro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    MainIntro.tStart = globalClock.getTime(format='float')
    MainIntro.status = STARTED
    thisExp.addData('MainIntro.started', MainIntro.tStart)
    MainIntro.maxDuration = None
    # keep track of which components have finished
    MainIntroComponents = MainIntro.components
    for thisComponent in MainIntro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "MainIntro" ---
    thisExp.currentRoutine = MainIntro
    MainIntro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *MainIntro_txt* updates
        
        # if MainIntro_txt is starting this frame...
        if MainIntro_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            MainIntro_txt.frameNStart = frameN  # exact frame index
            MainIntro_txt.tStart = t  # local t and not account for scr refresh
            MainIntro_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(MainIntro_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'MainIntro_txt.started')
            # update status
            MainIntro_txt.status = STARTED
            MainIntro_txt.setAutoDraw(True)
        
        # if MainIntro_txt is active this frame...
        if MainIntro_txt.status == STARTED:
            # update params
            pass
        
        # *MainIntro_key* updates
        waitOnFlip = False
        
        # if MainIntro_key is starting this frame...
        if MainIntro_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            MainIntro_key.frameNStart = frameN  # exact frame index
            MainIntro_key.tStart = t  # local t and not account for scr refresh
            MainIntro_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(MainIntro_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'MainIntro_key.started')
            # update status
            MainIntro_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(MainIntro_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(MainIntro_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if MainIntro_key.status == STARTED and not waitOnFlip:
            theseKeys = MainIntro_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
            _MainIntro_key_allKeys.extend(theseKeys)
            if len(_MainIntro_key_allKeys):
                MainIntro_key.keys = _MainIntro_key_allKeys[-1].name  # just the last key pressed
                MainIntro_key.rt = _MainIntro_key_allKeys[-1].rt
                MainIntro_key.duration = _MainIntro_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=MainIntro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            MainIntro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if MainIntro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in MainIntro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "MainIntro" ---
    for thisComponent in MainIntro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for MainIntro
    MainIntro.tStop = globalClock.getTime(format='float')
    MainIntro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('MainIntro.stopped', MainIntro.tStop)
    thisExp.nextEntry()
    # the Routine "MainIntro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    main_loop = data.TrialHandler2(
        name='main_loop',
        nReps=1.0, 
        method='random', 
        extraInfo=expInfo, 
        originPath=-1, 
        trialList=data.importConditions('conditions/main.xlsx'), 
        seed=None, 
        isTrials=True, 
    )
    thisExp.addLoop(main_loop)  # add the loop to the experiment
    thisMain_loop = main_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
    if thisMain_loop != None:
        for paramName in thisMain_loop:
            globals()[paramName] = thisMain_loop[paramName]
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    
    for thisMain_loop in main_loop:
        main_loop.status = STARTED
        if hasattr(thisMain_loop, 'status'):
            thisMain_loop.status = STARTED
        currentLoop = main_loop
        thisExp.timestampOnFlip(win, 'thisRow.t', format=globalClock.format)
        if thisSession is not None:
            # if running in a Session with a Liaison client, send data up to now
            thisSession.sendExperimentData()
        # abbreviate parameter names if possible (e.g. rgb = thisMain_loop.rgb)
        if thisMain_loop != None:
            for paramName in thisMain_loop:
                globals()[paramName] = thisMain_loop[paramName]
        
        # --- Prepare to start Routine "Ready" ---
        # create an object to store info about Routine Ready
        Ready = data.Routine(
            name='Ready',
            components=[Ready_txt, Ready_key],
        )
        Ready.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # create starting attributes for Ready_key
        Ready_key.keys = []
        Ready_key.rt = []
        _Ready_key_allKeys = []
        # store start times for Ready
        Ready.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Ready.tStart = globalClock.getTime(format='float')
        Ready.status = STARTED
        thisExp.addData('Ready.started', Ready.tStart)
        Ready.maxDuration = None
        # keep track of which components have finished
        ReadyComponents = Ready.components
        for thisComponent in Ready.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Ready" ---
        thisExp.currentRoutine = Ready
        Ready.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_loop, 'status') and thisMain_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Ready_txt* updates
            
            # if Ready_txt is starting this frame...
            if Ready_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Ready_txt.frameNStart = frameN  # exact frame index
                Ready_txt.tStart = t  # local t and not account for scr refresh
                Ready_txt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Ready_txt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Ready_txt.started')
                # update status
                Ready_txt.status = STARTED
                Ready_txt.setAutoDraw(True)
            
            # if Ready_txt is active this frame...
            if Ready_txt.status == STARTED:
                # update params
                pass
            
            # *Ready_key* updates
            waitOnFlip = False
            
            # if Ready_key is starting this frame...
            if Ready_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Ready_key.frameNStart = frameN  # exact frame index
                Ready_key.tStart = t  # local t and not account for scr refresh
                Ready_key.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Ready_key, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'Ready_key.started')
                # update status
                Ready_key.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(Ready_key.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(Ready_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if Ready_key.status == STARTED and not waitOnFlip:
                theseKeys = Ready_key.getKeys(keyList=['space'], ignoreKeys=["escape"], waitRelease=False)
                _Ready_key_allKeys.extend(theseKeys)
                if len(_Ready_key_allKeys):
                    Ready_key.keys = _Ready_key_allKeys[-1].name  # just the last key pressed
                    Ready_key.rt = _Ready_key_allKeys[-1].rt
                    Ready_key.duration = _Ready_key_allKeys[-1].duration
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Ready,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Ready.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Ready.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Ready.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Ready" ---
        for thisComponent in Ready.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Ready
        Ready.tStop = globalClock.getTime(format='float')
        Ready.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Ready.stopped', Ready.tStop)
        # the Routine "Ready" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "Trial" ---
        # create an object to store info about Routine Trial
        Trial = data.Routine(
            name='Trial',
            components=[],
        )
        Trial.status = NOT_STARTED
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from trial_code
        # ── 한 시행 전체 ──────────────────────────────────────────
        # PsychoPy 의 importConditions 는 '[' 로 시작하는 셀을 읽을 때 자동으로 eval 해서
        # 이미 파이썬 리스트로 넘겨준다. 그래서 문자열일 때만 json 으로 푼다.
        if isinstance(sentences_json, str):
            sentences = json.loads(sentences_json)
        else:
            sentences = [list(s) for s in sentences_json]
        is_prac = bool(int(practice))
        
        probe_response = None
        probe_rt       = None
        probe_correct  = None
        probe_done     = False
        
        for sentence in sentences:
            words, probe, probe_at = split_probe(sentence)
            start_x = sentence_start_x(words)      # 이 문장 내내 고정
        
            for step in range(len(words) + 1):
                # 검사단어 차례
                if probe is not None and not probe_done and step == probe_at:
                    draw_probe_frame(' '.join(words[:step]), probe, start_x)
                    win.flip()
                    probe_response, probe_rt = collect_response()
                    probe_correct = (probe_response == probe_correct_key(probe_type))
                    probe_done = True
                    if not PROBE_ALONE:
                        win.flip()          # 앞 어절과 함께 보여준 경우 화면을 비운다
                    if is_prac:
                        show_feedback(probe_correct)
        
                if step == len(words):
                    break
        
                make_line(' '.join(words[:step + 1]), start_x).draw()
                win.flip()
                core.wait(WORD_DURATION)
        
            # 논문 절차: 마지막 어절 제시 후 문장을 추가로 유지했다가,
            # 화면을 비우고 일정 시간이 지난 뒤 다음 문장을 제시한다.
            make_line(' '.join(words), start_x).draw()
            win.flip()
            core.wait(SENTENCE_HOLD)
            win.flip()
            core.wait(SENTENCE_ISI)
        
        # ── 이해검사 질문 ─────────────────────────────────────────
        make_center(question, y=0.10, height=0.06).draw()
        make_center('%s: %s    %s: %s' % (KEY_LEFT, opt1, KEY_RIGHT, opt2),
                    y=-0.10, height=0.06).draw()
        win.flip()
        quest_response, quest_rt = collect_response()
        quest_correct = (quest_response == ans_key)
        if is_prac:
            show_feedback(quest_correct)
        
        # ── 기록 ─────────────────────────────────────────────────
        thisExp.addData('probe_task',  'context' if TASK_MODE == 'context' else 'recognition')
        thisExp.addData('probe_resp',  probe_response)
        thisExp.addData('probe_corr',  int(bool(probe_correct)))
        thisExp.addData('probe_rt',    probe_rt)
        thisExp.addData('quest_resp',  quest_response)
        thisExp.addData('quest_corr',  int(quest_correct))
        thisExp.addData('quest_rt',    quest_rt)
        
        # 제시와 반응 수집이 모두 이 코드 안에서 끝나므로 프레임 루프는 돌지 않는다.
        continueRoutine = False
        
        # store start times for Trial
        Trial.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
        Trial.tStart = globalClock.getTime(format='float')
        Trial.status = STARTED
        thisExp.addData('Trial.started', Trial.tStart)
        Trial.maxDuration = None
        # keep track of which components have finished
        TrialComponents = Trial.components
        for thisComponent in Trial.components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "Trial" ---
        thisExp.currentRoutine = Trial
        Trial.forceEnded = routineForceEnded = not continueRoutine
        while continueRoutine:
            # if trial has changed, end Routine now
            if hasattr(thisMain_loop, 'status') and thisMain_loop.status == STOPPING:
                continueRoutine = False
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # check for quit (typically the Esc key)
            if defaultKeyboard.getKeys(keyList=["escape"]):
                thisExp.status = FINISHED
            if thisExp.status == FINISHED or endExpNow:
                endExperiment(thisExp, win=win)
                return
            # pause experiment here if requested
            if thisExp.status == PAUSED:
                pauseExperiment(
                    thisExp=thisExp, 
                    win=win, 
                    timers=[routineTimer, globalClock], 
                    currentRoutine=Trial,
                )
                # skip the frame we paused on
                continue
            
            # has a Component requested the Routine to end?
            if not continueRoutine:
                Trial.forceEnded = routineForceEnded = True
            # has the Routine been forcibly ended?
            if Trial.forceEnded or routineForceEnded:
                break
            # has every Component finished?
            continueRoutine = False
            for thisComponent in Trial.components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "Trial" ---
        for thisComponent in Trial.components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store stop times for Trial
        Trial.tStop = globalClock.getTime(format='float')
        Trial.tStopRefresh = tThisFlipGlobal
        thisExp.addData('Trial.stopped', Trial.tStop)
        # the Routine "Trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        # mark thisMain_loop as finished
        if hasattr(thisMain_loop, 'status'):
            thisMain_loop.status = FINISHED
        # if awaiting a pause, pause now
        if main_loop.status == PAUSED:
            thisExp.status = PAUSED
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[globalClock], 
            )
            # once done pausing, restore running status
            main_loop.status = STARTED
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'main_loop'
    main_loop.status = FINISHED
    
    if thisSession is not None:
        # if running in a Session with a Liaison client, send data up to now
        thisSession.sendExperimentData()
    # get names of stimulus parameters
    if main_loop.trialList in ([], [None], None):
        params = []
    else:
        params = main_loop.trialList[0].keys()
    # save data for this loop
    main_loop.saveAsExcel(filename + '.xlsx', sheetName='main_loop',
        stimOut=params,
        dataOut=['n','all_mean','all_std', 'all_raw'])
    
    # --- Prepare to start Routine "Outro" ---
    # create an object to store info about Routine Outro
    Outro = data.Routine(
        name='Outro',
        components=[Outro_txt, Outro_key],
    )
    Outro.status = NOT_STARTED
    continueRoutine = True
    # update component parameters for each repeat
    # create starting attributes for Outro_key
    Outro_key.keys = []
    Outro_key.rt = []
    _Outro_key_allKeys = []
    # store start times for Outro
    Outro.tStartRefresh = win.getFutureFlipTime(clock=globalClock)
    Outro.tStart = globalClock.getTime(format='float')
    Outro.status = STARTED
    thisExp.addData('Outro.started', Outro.tStart)
    Outro.maxDuration = None
    # keep track of which components have finished
    OutroComponents = Outro.components
    for thisComponent in Outro.components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "Outro" ---
    thisExp.currentRoutine = Outro
    Outro.forceEnded = routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Outro_txt* updates
        
        # if Outro_txt is starting this frame...
        if Outro_txt.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Outro_txt.frameNStart = frameN  # exact frame index
            Outro_txt.tStart = t  # local t and not account for scr refresh
            Outro_txt.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Outro_txt, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Outro_txt.started')
            # update status
            Outro_txt.status = STARTED
            Outro_txt.setAutoDraw(True)
        
        # if Outro_txt is active this frame...
        if Outro_txt.status == STARTED:
            # update params
            pass
        
        # *Outro_key* updates
        waitOnFlip = False
        
        # if Outro_key is starting this frame...
        if Outro_key.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Outro_key.frameNStart = frameN  # exact frame index
            Outro_key.tStart = t  # local t and not account for scr refresh
            Outro_key.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Outro_key, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Outro_key.started')
            # update status
            Outro_key.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(Outro_key.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(Outro_key.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if Outro_key.status == STARTED and not waitOnFlip:
            theseKeys = Outro_key.getKeys(keyList=None, ignoreKeys=["escape"], waitRelease=False)
            _Outro_key_allKeys.extend(theseKeys)
            if len(_Outro_key_allKeys):
                Outro_key.keys = _Outro_key_allKeys[-1].name  # just the last key pressed
                Outro_key.rt = _Outro_key_allKeys[-1].rt
                Outro_key.duration = _Outro_key_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if defaultKeyboard.getKeys(keyList=["escape"]):
            thisExp.status = FINISHED
        if thisExp.status == FINISHED or endExpNow:
            endExperiment(thisExp, win=win)
            return
        # pause experiment here if requested
        if thisExp.status == PAUSED:
            pauseExperiment(
                thisExp=thisExp, 
                win=win, 
                timers=[routineTimer, globalClock], 
                currentRoutine=Outro,
            )
            # skip the frame we paused on
            continue
        
        # has a Component requested the Routine to end?
        if not continueRoutine:
            Outro.forceEnded = routineForceEnded = True
        # has the Routine been forcibly ended?
        if Outro.forceEnded or routineForceEnded:
            break
        # has every Component finished?
        continueRoutine = False
        for thisComponent in Outro.components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "Outro" ---
    for thisComponent in Outro.components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store stop times for Outro
    Outro.tStop = globalClock.getTime(format='float')
    Outro.tStopRefresh = tThisFlipGlobal
    thisExp.addData('Outro.stopped', Outro.tStop)
    thisExp.nextEntry()
    # the Routine "Outro" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # mark experiment as finished
    endExperiment(thisExp, win=win)


def saveData(thisExp):
    """
    Save data from this experiment
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    """
    filename = thisExp.dataFileName
    # these shouldn't be strictly necessary (should auto-save)
    thisExp.saveAsWideText(filename + '.csv', delim='auto')
    thisExp.saveAsPickle(filename)


def endExperiment(thisExp, win=None):
    """
    End this experiment, performing final shut down operations.
    
    This function does NOT close the window or end the Python process - use `quit` for this.
    
    Parameters
    ==========
    thisExp : psychopy.data.ExperimentHandler
        Handler object for this experiment, contains the data to save and information about 
        where to save it to.
    win : psychopy.visual.Window
        Window for this experiment.
    """
    # stop any playback components
    if thisExp.currentRoutine is not None:
        for comp in thisExp.currentRoutine.getPlaybackComponents():
            comp.stop()
    if win is not None:
        # remove autodraw from all current components
        win.clearAutoDraw()
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed
        win.flip()
    # return console logger level to WARNING
    logging.console.setLevel(logging.WARNING)
    # mark experiment handler as finished
    thisExp.status = FINISHED
    # run any 'at exit' functions
    for fcn in runAtExit:
        fcn()
    logging.flush()


def quit(thisExp, win=None, thisSession=None):
    """
    Fully quit, closing the window and ending the Python process.
    
    Parameters
    ==========
    win : psychopy.visual.Window
        Window to close.
    thisSession : psychopy.session.Session or None
        Handle of the Session object this experiment is being run from, if any.
    """
    thisExp.abort()  # or data files will save again on exit
    # make sure everything is closed down
    if win is not None:
        # Flip one final time so any remaining win.callOnFlip() 
        # and win.timeOnFlip() tasks get executed before quitting
        win.flip()
        win.close()
    logging.flush()
    if thisSession is not None:
        thisSession.stop()
    # terminate Python process
    core.quit()


# if running this experiment as a script...
if __name__ == '__main__':
    # call all functions in order
    expInfo = showExpInfoDlg(expInfo=expInfo)
    thisExp = setupData(expInfo=expInfo)
    logFile = setupLogging(filename=thisExp.dataFileName)
    win = setupWindow(expInfo=expInfo)
    setupDevices(expInfo=expInfo, thisExp=thisExp, win=win)
    run(
        expInfo=expInfo, 
        thisExp=thisExp, 
        win=win,
        globalClock='float'
    )
    saveData(thisExp=thisExp)
    quit(thisExp=thisExp, win=win)
